<?php
$conexion = mysqli_connect("localhost","root","","kns");



?>