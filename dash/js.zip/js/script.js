$(document).ready(function() {
    var menu = 1;
    function burguers() {
        let burguer = "";
        $.ajax({
            url:"php/burguer.php",
            type:"GET",
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos){
                datos.forEach(dato => {
                    
                    burguer += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_papa" pk="${dato.id}">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(burguer);
             }else{
                    console.log("no hay hamburguesas");
             }
            }
            
        
            
        })
        
        
    }
    burguers();
    function papas() {
        let papa = "";
        $.ajax({
            url:"php/papas.php",
            type:"GET",
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos){
                datos.forEach(dato => {
                    
                  papa += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_papa">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(papa);
             }else{
                    console.log("no hay fritas");
             }
            }
            
        
            
        })
        
        
    }
    function bebida() {
        let bebida = "";
        $.ajax({
            url:"php/bebidas.php",
            type:"GET",
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos){
                datos.forEach(dato => {
                    
                  bebida += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_bebida">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(bebida);
             }else{
                    console.log("no hay bebidas");
             }
            }
            
        
            
        })
        
    }

    function buscarburguers() {
        let burguer = "";
        if($(".buscar").val() == "") {
            burguers();
        }{
        $.ajax({
            url:"php/buscarburguer.php",
            type:"POST",
            data: {busqueda: $(".buscar").val()},
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos != '404'){
                datos.forEach(dato => {
                    
                    burguer += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_papa" pk="${dato.id}">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(burguer);
             }else{
                $(".cosas_tabla").html("no se encontro nada");
             }
            }
            
        
            
        })
        
        }
    }
    function buscarpapas() {
        let papa = "";
        if($(".buscar").val() == "") {
            papas();
        }{
        $.ajax({
            url:"php/buscarpapas.php",
            type:"POST",
            data: {busqueda: $(".buscar").val()},
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos != '404'){
                datos.forEach(dato => {
                    console.log(dato.id);
                    papa += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_papa" pk="${dato.id}">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(papa);
             }else{
                $(".cosas_tabla").html("no se encontro nada");
             }
            }
            
        
            
        })
        
        }
    }
    function buscarbebidas() {
        let bebidas = "";
        if($(".buscar").val() == "") {
            bebida();
        }{
        $.ajax({
            url:"php/buscarbebidas.php",
            type:"POST",
            data: {busqueda: $(".buscar").val()},
            success:function(resu){
             let datos = JSON.parse(resu);
             if(datos != '404'){
                datos.forEach(dato => {
                    
                    bebidas += `
                    <div class="tabla_campo">
                    <div class="campo campo_nombre">${dato.nombre}</div>
                    <div class="campo campo_precio">${dato.precio}</div>
                    <div class="campo campo_descuento">${dato.descuento}</div>
                    <div class="campo campo_boton"> <button class="modificar boton_papa" pk="${dato.id}">Editar</button></div>
                    </div> 
                  `  
                });
                $(".cosas_tabla").html(bebidas);
             }else{
                $(".cosas_tabla").html("no se encontro nada");
             }
            }
            
        
            
        })
        
        }
    }

    function selecion(){
        if(menu == 1){
            burguers();
        }else if(menu == 2){
            papas();
        }else if(menu == 3){
            bebida();
        }


    }

    $(document).on("click", "#burguer", function() {
        menu = 1;
        console.log("burguer");
        let newmenu = `
        <div class="left_button burger seleccionado" id="burguer">
                <div class="button_logo"> 1 </div>
                <div class="button_text"> Burguer </div>
             </div>

             <div class="left_button seleccionar" id="papas">
                <div class="button_logo"> 2 </div>
                <div class="button_text"> Papas </div>
             </div>
               
             <div class="left_button seleccionar" id="bebida">
                <div class="button_logo"> 3 </div>
                <div class="button_text"> Bebida </div>
             </div>
        `;
        $(".left").html(newmenu);
        selecion();
    });

    $(document).on("click", "#papas", function() {
        menu = 2;
        console.log("papas");
        let newmenu = `
        <div class="left_button burger seleccionar" id="burguer">
                <div class="button_logo"> 1 </div>
                <div class="button_text"> Burguer </div>
             </div>

             <div class="left_button seleccionado" id="papas">
                <div class="button_logo"> 2 </div>
                <div class="button_text"> Papas </div>
             </div>
               
             <div class="left_button seleccionar" id="bebida">
                <div class="button_logo"> 3 </div>
                <div class="button_text"> Bebida </div>
             </div>
        `;
        $(".left").html(newmenu);
        selecion();
        console.log(menu);
    });

    $(document).on("click", "#bebida", function() {
        menu = 3;
        console.log("bebida");
        let newmenu = `
        <div class="left_button burger seleccionar" id="burguer">
                <div class="button_logo"> 1 </div>
                <div class="button_text"> Burguer </div>
             </div>

             <div class="left_button seleccionar" id="papas">
                <div class="button_logo"> 2 </div>
                <div class="button_text"> Papas </div>
             </div>
               
             <div class="left_button seleccionado" id="bebida">
                <div class="button_logo"> 3 </div>
                <div class="button_text"> Bebida </div>
             </div>
        `;
        $(".left").html(newmenu);
        selecion();
    });
let almacenar_tiempo;                
let tiempo = 250;  


$('.input_buscador').on('input', function () {
    clearTimeout(almacenar_tiempo);
});

$('.buscar').on('keyup', function () {
    clearTimeout(almacenar_tiempo);
    almacenar_tiempo = setTimeout(function(){
        switch(menu){
            case 1:
                buscarburguers();
                break;
        
            case 2:
                buscarpapas();
                break;
            case 3:
                buscarbebidas();
                break;
        }
    }, tiempo);
});

$(document).on("click", ".nueva", function() {
    let agregar = document.querySelector('dialog');
    agregar.showModal();

});
    
$(document).on("click", ".cerrar_boton", function() {
    let agregar = document.querySelector('dialog');
    agregar.close();
})

$(document).on("click", "#agregarboton", function() {
    console.log($(".agregar_nombre").val());
    
    $.ajax({
    url:"php/agregar.php",
    type:"POST",
    data: {nombre: $(".agregar_nombre").val(), precio:$(".agregar_precio").val(), descuento: $(".agregar_descuento").val(), descripcion: $(".agregar_descripcion").val(), menu:menu},
    success:function(resu){
        let agregar = document.querySelector('dialog');
        agregar.close();
        selecion()
        
    }
})
})
$(document).on("click", ".modificar", function() {
console.log(this.getAttribute("pk"));



})

});